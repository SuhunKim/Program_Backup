using System.IO.Compression;

namespace PC_BackUp.Services;

public sealed class BackupService
{
    private const int MaxNameCollisionRetries = 99; // 같은 분에 만든 백업 개수 상한(초과 시 실패 처리)

    private readonly BackupCatalogService m_oCatalogService;

    public BackupService(BackupCatalogService oCatalogService)
    {
        m_oCatalogService = oCatalogService;
    }

    public async Task<(OperationResult Result, BackupRecord? Record)> CreateAsync(
        AppSettings settings,
        BackupKind kind,
        string nameSuffix = "",
        IProgress<int>? progress = null,
        CancellationToken cancellationToken = default)
    {
        settings = settings.Snapshot();
        var errors = settings.Validate();
        if (errors.Count > 0)
            return (OperationResult.Failure(string.Join(Environment.NewLine, errors)), null);

        var suffix = FileNaming.SanitizeSuffix(nameSuffix);

        try
        {
            using var operation = OperationCoordinator.Acquire(settings.GetSourceRoot(), settings.BackupRootPath);
            var record = await Task.Run(() =>
            {
                var sourceRoot = Path.GetFullPath(settings.GetSourceRoot());
                var backupRoot = Path.GetFullPath(settings.BackupRootPath);
                PathSafety.EnsureNoReparsePoints(backupRoot);
                Directory.CreateDirectory(backupRoot);
                PathSafety.EnsureNoReparsePoints(backupRoot);

                var baseName = ResolveAvailableBaseName(backupRoot, kind, suffix);
                var destination = Path.Combine(backupRoot, string.Format("{0}{1}", baseName, SuffixFor(kind)));

                var selectiveFolderNames = settings.GetSelectiveFolderNames();
                if (kind == BackupKind.SelectiveFolders)
                    EnsureSelectiveFoldersExist(sourceRoot, selectiveFolderNames);

                var roots = kind == BackupKind.FullZip
                    ? new[] { sourceRoot }
                    : selectiveFolderNames.Select(name => Path.Combine(sourceRoot, name));
                var files = roots.SelectMany(root => EnumerateSourceFiles(root, backupRoot)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();

                if (files.Count == 0)
                    throw new InvalidOperationException("백업 조건에 맞는 파일이 없습니다.");

                progress?.Report(0);
                var manifest = BackupManifestService.Create(settings, kind, files, cancellationToken);
                progress?.Report(5);
                // [Codex - 2026.10.19] 완료되기 전에는 카탈로그에서 인식하지 않는 이름으로 작성한다.
                var pending = Path.Combine(backupRoot, string.Format(".pcbackup-pending-{0}", Guid.NewGuid().ToString("N")));
                try
                {
                    if (kind == BackupKind.FullZip)
                        CreateZip(sourceRoot, pending, files, progress, cancellationToken);
                    else
                        CopyToFolder(sourceRoot, pending, files, progress, cancellationToken);
                    progress?.Report(85);
                    BackupManifestService.Write(pending, kind, manifest);
                    BackupManifestService.Verify(pending, manifest, cancellationToken);
                    cancellationToken.ThrowIfCancellationRequested();
                    if (kind == BackupKind.FullZip) File.Move(pending, destination);
                    else Directory.Move(pending, destination);
                    progress?.Report(100);
                }
                finally
                {
                    try
                    {
                        if (File.Exists(pending)) File.Delete(pending);
                        if (Directory.Exists(pending)) Directory.Delete(pending, true);
                    }
                    catch { /* 완료본은 보존하고 미완성 잔여물은 카탈로그에서 제외한다. */ }
                }

                // [Codex - 2026.10.19] 생성 성공을 별도 카탈로그 재탐색의 성공 여부와 분리한다.
                return new BackupRecord { FullPath = destination, FileName = Path.GetFileName(destination),
                    Kind = kind, CreatedAt = manifest.CreatedUtc.ToLocalTime(), Manifest = manifest,
                    SizeBytes = kind == BackupKind.FullZip ? new FileInfo(destination).Length : manifest.Files.Sum(item => item.Length) };
            }, cancellationToken);

            return (OperationResult.Success(string.Format("백업이 완료되었습니다.\n{0}", record.FileName)), record);
        }
        catch (OperationCanceledException)
        {
            return (OperationResult.Canceled("백업이 취소되었습니다."), null);
        }
        catch (Exception exception)
        {
            return (OperationResult.Failure(string.Format("백업 중 오류가 발생했습니다.\n{0}", exception.Message), exception), null);
        }
    }

    /// <summary>GUI가 파일명 다이얼로그에서 실시간 미리보기를 표시할 때 쓰는 순수 헬퍼.</summary>
    public static string PreviewFileName(string nameSuffix, BackupKind kind)
    {
        var suffix = FileNaming.SanitizeSuffix(nameSuffix);
        return string.Format("{0}{1}", BuildBaseName(DateTime.Now, suffix, 0), SuffixFor(kind));
    }

    /// <summary>
    /// 파일명 규칙: "yyyyMMdd - HHmm[ - 접미사(예: 프로젝트 이름)][ - 01]".
    /// 순번(counter)은 같은 분에 두 번째 이후로 만들 때만 붙는다(0이면 표시하지 않음).
    /// </summary>
    private static string BuildBaseName(DateTime createdAt, string suffix, int counter)
    {
        var parts = new List<string> { createdAt.ToString("yyyyMMdd"), createdAt.ToString("HHmm") };
        if (suffix.Length > 0) parts.Add(suffix);
        if (counter > 0) parts.Add(counter.ToString("00"));
        return string.Join(" - ", parts);
    }

    // 전체 백업은 ZIP 파일, 선택 폴더 백업은 날짜 기반 폴더를 만들어 파일을 복사한다.
    private static string SuffixFor(BackupKind kind) =>
        kind == BackupKind.FullZip ? ".zip" : "_files";

    /// <summary>
    /// 현재 시각 기준으로 사용 가능한 파일명을 찾는다. 같은 분에 이미 파일이 있으면 시간을 바꾸지 않고
    /// " - 01", " - 02"... 순번만 붙여 구분한다(첫 번째는 순번 없이 그대로 사용).
    /// </summary>
    private static string ResolveAvailableBaseName(string backupRoot, BackupKind kind, string suffix)
    {
        var now = DateTime.Now;
        var kindSuffix = SuffixFor(kind);
        for (var counter = 0; counter <= MaxNameCollisionRetries; counter++)
        {
            var baseName = BuildBaseName(now, suffix, counter);
            var candidate = Path.Combine(backupRoot, string.Format("{0}{1}", baseName, kindSuffix));
            if (!File.Exists(candidate) && !Directory.Exists(candidate))
                return baseName;
        }

        throw new InvalidOperationException("사용 가능한 백업 파일명을 찾지 못했습니다. 백업 폴더를 정리한 뒤 다시 시도하세요.");
    }

    // [Codex - 2026.10.19] 접근 실패는 경로를 포함해 드러내고 저장소·링크는 내려가기 전에 제외한다.
    private static IEnumerable<string> EnumerateSourceFiles(string sourceRoot, string backupRoot)
    {
        PathSafety.EnsureNoReparsePoints(sourceRoot);
        if ((File.GetAttributes(sourceRoot) & FileAttributes.ReparsePoint) != 0)
            throw new IOException(string.Format("백업 원본이 연결 경로입니다: {0}", sourceRoot));
        var pending = new Stack<string>();
        pending.Push(sourceRoot);
        while (pending.Count > 0)
        {
            var directory = pending.Pop();
            string[] entries;
            try { entries = Directory.GetFileSystemEntries(directory); }
            catch (Exception exception) when (exception is IOException or UnauthorizedAccessException)
            {
                throw new IOException(string.Format("백업 항목을 읽지 못했습니다: {0}", directory), exception) { Data = { ["Path"] = directory } };
            }
            foreach (var entry in entries)
            {
                var fullPath = Path.GetFullPath(entry);
                if (IsSameOrChildPath(fullPath, backupRoot)) continue;
                FileAttributes attributes;
                try { attributes = File.GetAttributes(fullPath); }
                catch (Exception exception) when (exception is IOException or UnauthorizedAccessException)
                {
                    throw new IOException(string.Format("백업 항목을 확인하지 못했습니다: {0}", fullPath), exception) { Data = { ["Path"] = fullPath } };
                }
                if ((attributes & FileAttributes.ReparsePoint) != 0)
                    throw new IOException(string.Format("연결 경로는 완전 백업을 보장할 수 없습니다: {0}", fullPath));
                if ((attributes & FileAttributes.Directory) != 0) pending.Push(fullPath);
                else yield return fullPath;
            }
        }
    }

    private static void EnsureSelectiveFoldersExist(string sourceRoot, IReadOnlyList<string> folderNames)
    {
        var missingFolders = folderNames
            .Where(name => !Directory.Exists(Path.Combine(sourceRoot, name)))
            .ToList();

        if (missingFolders.Count > 0)
            throw new DirectoryNotFoundException(
                string.Format("선별 백업 폴더를 찾을 수 없습니다: {0}", string.Join(", ", missingFolders)));
    }

    private static bool IsConfiguredFolderItem(
        string sourceRoot,
        string filePath,
        IReadOnlyList<string> folderNames)
    {
        var relativePath = Path.GetRelativePath(sourceRoot, filePath);
        return SelectiveFolderMatch.IsInsideAnyFolder(relativePath, folderNames);
    }

    private static void CreateZip(
        string sourceRoot,
        string destination,
        IReadOnlyList<string> files,
        IProgress<int>? progress,
        CancellationToken cancellationToken)
    {
        using var stream = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None);
        using var archive = new ZipArchive(stream, ZipArchiveMode.Create);
        var totalBytes = files.Sum(file => new FileInfo(file).Length);
        long processed = 0;

        try
        {
            for (var index = 0; index < files.Count; index++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var relativePath = Path.GetRelativePath(sourceRoot, files[index]);
                using var input = File.OpenRead(files[index]);
                using var output = archive.CreateEntry(relativePath, CompressionLevel.Optimal).Open();
                FileTransfer.Copy(input, output, cancellationToken, count =>
                {
                    processed += count;
                    progress?.Report(5 + (int)Math.Min(75, processed * 75d / Math.Max(1, totalBytes)));
                });
            }
        }
        catch
        {
            archive.Dispose();
            stream.Dispose();
            File.Delete(destination);
            throw;
        }
    }

    private static void CopyToFolder(
        string sourceRoot,
        string destination,
        IReadOnlyList<string> files,
        IProgress<int>? progress,
        CancellationToken cancellationToken)
    {
        Directory.CreateDirectory(destination);
        var totalBytes = files.Sum(file => new FileInfo(file).Length);
        long processed = 0;
        try
        {
            for (var index = 0; index < files.Count; index++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var relativePath = Path.GetRelativePath(sourceRoot, files[index]);
                var targetPath = Path.Combine(destination, relativePath);
                Directory.CreateDirectory(Path.GetDirectoryName(targetPath)!);
                FileTransfer.CopyFile(files[index], targetPath, cancellationToken, count =>
                {
                    processed += count;
                    progress?.Report(5 + (int)Math.Min(75, processed * 75d / Math.Max(1, totalBytes)));
                });
            }
        }
        catch
        {
            try { Directory.Delete(destination, true); }
            catch { }
            throw;
        }
    }

    private static bool IsSameOrChildPath(string candidate, string parent)
    {
        var normalizedCandidate = Path.TrimEndingDirectorySeparator(Path.GetFullPath(candidate));
        var normalizedParent = Path.TrimEndingDirectorySeparator(Path.GetFullPath(parent));
        return normalizedCandidate.Equals(normalizedParent, StringComparison.OrdinalIgnoreCase) ||
               normalizedCandidate.StartsWith(string.Format("{0}{1}", normalizedParent, Path.DirectorySeparatorChar),
                   StringComparison.OrdinalIgnoreCase);
    }
}
